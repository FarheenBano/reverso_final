from urllib import request
from django.shortcuts import render,HttpResponse
from .models import Contact,Demo,Payment

# Create your views here.
def index(request):
    # return HttpResponse("Hello")
    return render(request,'index.html')

def job_gurantee(request):
    # return HttpResponse("Hello")
    return render(request,'job_gurantee.html')

def protocol_testing(request):
    #return HttpResponse("Hello")
     return render(request,'protocol_testing.html')

def about(request):
    # return HttpResponse("Hello")
    return render(request,'about.html')

def contact(request):
    if request.method == "POST":
        name = request.POST.get('name', '')
        email = request.POST.get('email', '')
        phone = request.POST.get('phone', '')
        city = request.POST.get('city', '')
        msg = request.POST.get('msg', '')
        contact = Contact(name=name, email=email, phone=phone, city=city, msg=msg)
        contact.save()
    return render(request, 'contact.html')
    # return HttpResponse("Hello")

  #  return render(request,'contact.html')

def free_demo(request):
    if request.method == "POST":
        name = request.POST.get('name', '')
        email = request.POST.get('email', '')
        phone = request.POST.get('phone', '')
        city = request.POST.get('city', '')
        course = request.POST.get('course', '')
        freedemo = Demo(name=name, email=email, phone=phone, city=city, course=course)
        freedemo.save()
    return render(request, 'free_demo.html')

def fee_payment(request):
    return render(request,'fee_payment.html')

def protocol_payment(request):
    if request.method == "POST":
        name = request.POST.get('name', '')
        email = request.POST.get('email', '')
        phone = request.POST.get('phone', '')
        city = request.POST.get('city', '')
        fee_payment = Payment(name=name, email=email, phone=phone, city=city)
        fee_payment.save()
    return render(request,'protocol_payment.html')

def view(request):
    context = {'metadata': {'attr-1': 'value1', 'attr-2': 'value2'}}
    return render(request, 'base.html', context)


def faq(request):
    return render(request,'faq.html')

def python_training(request):
    return render(request,'python_training.html')


def python_training(request):
    return render(request,'python_training.html')


def java_training(request):
    return render(request,'java_training.html')


def c_prog(request):
    return render(request,'c_prog.html')


def telecom(request):
    return render(request,'telecom.html')


def industrial_training(request):
    return render(request,'industrial_training.html')


def technical(request):
    return render(request,'technical.html')

def student_information_form(request):
    return render(request,'student_information_form.html')


def employee(request):
    return render(request,'employee.html')

def resume(request):
    return render(request,'resume.html')

def student_feedback(request):
    return render(request,'student_feedback.html')

def feedback_demo_class(request):
    return render(request,'feedback_demo_class.html')

def staffing_services(request):
    return render(request,'staffing_services.html')