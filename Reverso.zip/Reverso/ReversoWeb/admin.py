from django.contrib import admin
from .models import Contact, Demo, Payment
admin.site.register(Contact)
admin.site.register(Demo)
admin.site.register(Payment)


# Register your models here.
