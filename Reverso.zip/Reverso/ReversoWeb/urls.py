from django.contrib import admin
from django.urls import path,include
from ReversoWeb import views
urlpatterns = [
    path("",views.index,name='home'),
    path("job_gurantee",views.job_gurantee,name='job_gurantee'),
    path("protocol_testing",views.protocol_testing,name='protocol_testing'),
    path("about",views.about,name='about'),
    path("contact", views.contact, name='contact'),
    path("free_demo", views.free_demo, name='free_demo'),
    path("fee_payment", views.fee_payment, name='fee_payment'),
    path("protocol_payment", views.protocol_payment, name='protocol_payment'),
    path("faq", views.faq, name='faq'),
    path("python_training", views.python_training, name='python_training'),
    path("java_training", views.java_training, name='java_training'),
    path("c_prog", views.c_prog, name='c_prog'),
    path("telecom", views.telecom,name='telecom'),
    path("industrial_training", views.industrial_training, name='industrial_training'),
    path("technical", views.technical, name='technical'),
    path("student_information_form", views.student_information_form, name='student_information_form'),
    path("employee", views.employee, name='employee'),
    path("resume", views.resume, name='resume'),
    path("student_feedback", views.student_feedback, name='student_feedback'),
    path("feedback_demo_class", views.feedback_demo_class, name='feedback_demo_class'),
    path("staffing_services", views.staffing_services, name='staffing_services'),


]